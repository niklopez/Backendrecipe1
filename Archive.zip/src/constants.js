export const SERVER_URL = 'http://localhost:8080';

export const SEMESTERS = [
  { year:2020, semester:'Fall'},
  { year:2021, semester:'Spring'},
  { year:2021, semester:'Fall'}
] ;
