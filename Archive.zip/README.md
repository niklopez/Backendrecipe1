# CST438 Software Engineering California State University Monterey Bay
# Student Registration project Front End application

This application is written in React and requires node.js to be installed.

